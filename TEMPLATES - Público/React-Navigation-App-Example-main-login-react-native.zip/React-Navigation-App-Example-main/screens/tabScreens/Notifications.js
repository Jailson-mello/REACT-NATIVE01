import { Text, View } from "react-native";

export default function Notifications() {
  return (
    <View>
      <Text>Hello</Text>
    </View>
  );
}
